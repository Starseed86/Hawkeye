## Using FormStyleManager

[release:Release 0.5](146) introduces new component called **FormStyleManager**. It's a central place that defines styles available for all forms in your application. The idea is that when you have multiple forms using the same styling you can define this style in only one place and reuse on every form. For this reason **FormStyleManager** maintains a library of available **FormStyles**. Whats more this library can be loaded and saved to a file. This allows the application to have multiple skins that can be changed at runtime. 

In order to load a style library you use the static **Load** method of the **FormStyleManager** class. For example to load default style library for your application you can put following line in it's Main method: 
{{
FormStyleManager.Load("MyLibrary.fsl");
}}
After that you can apply styles from this library to any form that inherits from the **CustomBorderForm** class. To do this you only need to set the **UseFormStyleManger** property to **true**. Optionally, you can specify which style to apply to this particular form using the **FormStyleName** property or leave it empty so that form uses the default style.  

However, if you don't want to use FormStyle libraries you can still create a single **FormStyle** (earlier called **CustomBorderAppearance**) in your code as before. In previous versions it was done by overriding the **CreateBorderAppearance** property. Now this can be done at any time by assigning your style to **FormStyle** property. In this case don't forget to leave **UseFormStyleManager** property set to false.