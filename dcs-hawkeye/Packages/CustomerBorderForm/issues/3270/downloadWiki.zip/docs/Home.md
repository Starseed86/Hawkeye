## Welcome

This project is a small library that extends Windows Forms with ability to customize the windows's non-client area. This allows you to create custom skins for any window and give your application consistent and unique look. The project includes also an interactive editor to easily create own skins.

![](Home_Sample1.jpg)

Until we migrate to CodePlex you can learn more on my blog: Drawing Custom Borders in Windows Forms [Part 1](http://geekswithblogs.net/kobush/articles/CustomBorderForms.aspx), [Part 2](http://geekswithblogs.net/kobush/articles/CustomBorderForms2.aspx), and [Part 3](http://geekswithblogs.net/kobush/articles/CustomBorderForms3.aspx)

Earlier versions can be found on [ProjectDistributor](http://projectdistributor.net/Projects/Project.aspx?projectId=135)

[Developers](Developers)

## Documentation
* [Painting NonClient Area](Painting-NonClient-Area)
* [Using FormStyleManager](Using-FormStyleManager)
* [Using FormStyleEditor](Using-FormStyleEditor)