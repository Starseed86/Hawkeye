Here is a list o people involved in the project. The list is not mandantory so you don't have to reveal your true name or contact data if you don't want to.

|| Name || Role || Country || Contact || Website ||
| Szymon Kobalczyk (kobush) | Coordinator | Poland | skobalczyk (AT) google com | http://geekswithblogs.net/kobush |
| Philippe DA SILVA (amadrias) | Developer | France | amadrias (AT) hotmail com | None for the moment |
| Cdemez | Developer | | | |
| ChristianKusmanow | Developer| | | |
| codeable | Developer | | | |