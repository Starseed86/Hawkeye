﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Lizard")]
[assembly: AssemblyDescription("Lizard Skined Forms")]
