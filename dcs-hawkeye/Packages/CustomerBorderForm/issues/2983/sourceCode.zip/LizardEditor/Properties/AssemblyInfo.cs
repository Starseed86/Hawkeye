﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("LizardEditor")]
[assembly: AssemblyDescription("Lizard Skined Forms Editor")]
