﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Demo")]
[assembly: AssemblyDescription("Lizard Skined Forms Demo")]
